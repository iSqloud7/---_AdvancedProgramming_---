package _18LoadedCoinTest;

import java.util.Random;
import java.util.Scanner;

public class LoadedCoinTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int probability = scanner.nextInt();

        // Testing Coin class
        Coin c = new Coin();
        int heads = countHeads(c, 1000);
        printResult(heads, 450, 550);

        // Testing LoadedCoin class
        c = new LoadedCoin(probability);
        heads = countHeads(c, 1000);
        printResult(heads, probability * 10 - 50, probability * 10 + 50);
    }

    private static int countHeads(Coin coin, int n) {
        int heads = 0;
        for (int i = 0; i < n; i++) {
            SIDE side = coin.flip();
            if (side == SIDE.HEAD) {
                heads++;
            }
        }
        return heads;
    }

    private static void printResult(int heads, int lowerBound, int upperBound) {
        if (heads > lowerBound && heads < upperBound) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}

enum SIDE {
    HEAD, TAIL
}

class Coin {
    public SIDE flip() {
        Random random = new Random();
        boolean isHead = random.nextBoolean();
        if (isHead) {
            return SIDE.HEAD;
        } else {
            return SIDE.TAIL;
        }
    }
}

class LoadedCoin extends Coin {
    private int probability;

    public LoadedCoin(int probability) {
        this.probability = probability;
    }

    @Override
    public SIDE flip() {
        Random random = new Random();
        int randomValue = random.nextInt(100);

        if (randomValue < probability) {
            return SIDE.HEAD;
        } else {
            return SIDE.TAIL;
        }
    }
}

