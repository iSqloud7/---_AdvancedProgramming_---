package _27RiskTester;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

class Round {
    private final List<Integer> attacker;
    private final List<Integer> defender;

    public List<Integer> getAttacker() {
        return attacker;
    }

    public List<Integer> getDefender() {
        return defender;
    }

    public Round(String line) {
        String[] parts = line.split(";");
        attacker = parseDice(parts[0]);
        defender = parseDice(parts[1]);

    }

    public List<Integer> parseDice(String line) {
        return Arrays.stream(line.split("\\s+"))
                .map(dice -> Integer.parseInt(dice))
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
    }
}

class Risk {
    public void processAttacksData(InputStream inputStream) {
        Scanner scanner = new Scanner(inputStream);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            Round round = new Round(line);
            int attacker = 0;
            int defender = 0;
            for (int i = 0; i < 3; i++) {
                if (round.getAttacker().get(i) > round.getDefender().get(i)) {
                    attacker++;
                } else {
                    defender++;
                }
            }
            System.out.println(attacker + " " + defender);
        }
    }
}

public class RiskTester {
    public static void main(String[] args) {
        Risk risk = new Risk();
        risk.processAttacksData(System.in);
    }
}
