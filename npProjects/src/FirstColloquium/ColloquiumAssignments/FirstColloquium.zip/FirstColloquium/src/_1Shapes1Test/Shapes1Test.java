package _1Shapes1Test;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Square {
    int size;

    public Square(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    public int perimeter() {
        return 4 * size;
    }
}

class Canvas implements Comparable<Canvas> {
    private String ID;
    List<Square> squares;

    public Canvas(String ID, List<Square> squares) {
        this.ID = ID;
        this.squares = squares;
    }

    public String getID() {
        return ID;
    }

    public static Canvas create(String line) {
//        Canvas -> 364fbe94 24 30 22 33 32 30 37 18 29 27 33 21 27 26
        String[] parts = line.split("\\s+");
        String ID = parts[0]; // -> ID на позиција 0
        List<Square> squares = new ArrayList<>();
//        for(int i=1; i<parts.length; i++){
//            squares.add(new Square(Integer.parseInt(parts[i])));
//        }
        squares = Arrays.stream(parts)
                .skip(1) // скок за еден елемент
                .map(sizeStr -> new Square(Integer.parseInt(sizeStr)))
                .collect(Collectors.toList());
        return new Canvas(ID, squares);
    }

    int totalSquares() {
        return squares.size();
    }

    int totalPerimeter() {
        return squares.stream()
                .mapToInt(square -> square.perimeter())
                .sum();
    }

    @Override
    public int compareTo(Canvas other) {
        return Integer.compare(this.totalPerimeter(), other.totalPerimeter());
    }

    @Override
    public String toString() {
//        canvas_id squares_count total_squares_perimeter.
//        364fbe94 14 1556
        return String.format("%s %d %d",
                ID, totalSquares(), totalPerimeter());
    }
}

class ShapesApplication {
    List<Canvas> canvases;

    public ShapesApplication() {
        canvases = new ArrayList<>(); // -> чување листа на Canvas-и
    }

    public int readCanvases(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
//         -> една линија претставува еден Canvas -> 364fbe94 24 30 22 33 32 30 37 18 29 27 33 21 27 26
        canvases = bufferedReader.lines()
                .map(line -> Canvas.create(line))
                .collect(Collectors.toList());
        bufferedReader.close();
        return canvases.stream()
                .mapToInt(canvas -> canvas.totalSquares())
                .sum();
    }

    public void printLargestCanvasTo(PrintStream out) {
//        364fbe94 14 1556
        PrintWriter printWriter = new PrintWriter(out);
        Canvas max = canvases.stream()
                .max(Comparator.naturalOrder())
                .get();
        printWriter.println(max);
        printWriter.flush();
    }
}

public class Shapes1Test {

    public static void main(String[] args) {
        ShapesApplication shapesApplication = new ShapesApplication();

        System.out.println("===READING SQUARES FROM INPUT STREAM===");
        try {
            System.out.println(shapesApplication.readCanvases(System.in));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println("===PRINTING LARGEST CANVAS TO OUTPUT STREAM===");
        shapesApplication.printLargestCanvasTo(System.out);

    }
}
