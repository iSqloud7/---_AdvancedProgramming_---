package _2Shapes2Test;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

enum Type {
    CIRCLE, SQUARE
}

class Circle extends Shape {
    public Circle(int side) {
        super(Type.CIRCLE, side);
    }

    @Override
    public double getArea() {
        return Math.PI * side * side;
    }
}

class Square extends Shape {

    public Square(int side) {
        super(Type.SQUARE, side);
    }

    @Override
    public double getArea() {
        return side * side;
    }
}

abstract class Shape implements Comparable<Shape> {
    protected Type type;
    protected int side;

    public Shape(Type type, int side) {
        this.type = type;
        this.side = side;
    }

    public Type getType() {
        return type;
    }

    public int getSide() {
        return side;
    }

    public abstract double getArea();

    @Override
    public int compareTo(Shape other) {
        return Double.compare(getArea(), other.getArea());
    }
}

class Canvas implements Comparable<Canvas> {
    //    0cc31e47 C 27 C 13 C 29 C 15 C 22
    private String ID;
    private List<Shape> shapes;

    public String getID() {
        return ID;
    }

    public Canvas(String line) {
        this.shapes = new ArrayList<>();
        String[] parts = line.split("\\s+");
        this.ID = parts[0];
        for (int i = 1; i < parts.length; i += 2) {
            if (parts[i].equals("C")) {
                shapes.add(new Circle(Integer.parseInt(parts[i + 1])));
            } else if (parts[i].equals("S")) {
                shapes.add(new Square(Integer.parseInt(parts[i + 1])));
            }
        }
    }

    public double getMax() {
        return Collections.max(shapes).getArea();
    }

    public double getMin() {
        return Collections.min(shapes).getArea();
    }

    public double getArea() {
        return shapes.stream()
                .mapToDouble(Shape::getArea)
                .sum();
    }

    public double averageArea() {
        return shapes.stream()
                .mapToDouble(Shape::getArea)
                .average()
                .getAsDouble();
    }

    public long totalCircles() {
        return shapes.stream()
                .filter(i -> i.getType()
                        .equals(Type.CIRCLE))
                .count();
    }

    public long totalSquares() {
        return shapes.stream()
                .filter(i -> i.getType()
                        .equals(Type.SQUARE))
                .count();
    }

    @Override
    public int compareTo(Canvas other) {
        return Double.compare(getArea(), other.getArea());
    }

    @Override
    public String toString() {
        return String.format("%s %d %d %d %.2f %.2f %.2f",
                ID, shapes.size(), totalCircles(), totalSquares(), getMin(), getMax(), averageArea());
    }
}

class IrregularCanvasException extends Exception {
    public IrregularCanvasException(String message) {
        super(message);
    }
}

class ShapesApplication {
    private List<Canvas> canvases;
    private double maxArea;

    ShapesApplication(double maxArea) {
        this.maxArea = maxArea;
        this.canvases = new ArrayList<>();
    }

    public void addCanvas(Canvas canvas) throws IrregularCanvasException {
        if (canvas.getMax() > maxArea) {
            throw new IrregularCanvasException(String.format("Canvas %s has a shape with area larger than %.2f",
                    canvas.getID(), maxArea));
        }
        canvases.add(canvas);
    }

    public void readCanvases(InputStream inputStream) {
        Scanner scanner = new Scanner(inputStream);
        while (scanner.hasNextLine()) {
            try {
                addCanvas(new Canvas(scanner.nextLine()));
            } catch (IrregularCanvasException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void printCanvases(PrintStream os) {
        canvases.sort(Collections.reverseOrder());
        canvases.forEach(os::println);
    }
}

public class Shapes2Test {

    public static void main(String[] args) {

        ShapesApplication shapesApplication = new ShapesApplication(10000);

        System.out.println("===READING CANVASES AND SHAPES FROM INPUT STREAM===");
        shapesApplication.readCanvases(System.in);

        System.out.println("===PRINTING SORTED CANVASES TO OUTPUT STREAM===");
        shapesApplication.printCanvases(System.out);


    }
}
