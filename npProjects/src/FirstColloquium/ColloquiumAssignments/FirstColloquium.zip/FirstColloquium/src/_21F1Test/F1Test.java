package _21F1Test;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

class Lap implements Comparable<Lap> {
    private int minutes;
    private int seconds;
    private int milliseconds;

    public Lap(String line) {
        String[] parts = line.split(":");
        this.minutes = Integer.parseInt(parts[0]);
        this.seconds = Integer.parseInt(parts[1]);
        this.milliseconds = Integer.parseInt(parts[2]);
    }

    @Override
    public int compareTo(Lap other) {
        if (minutes != other.minutes) {
            return minutes - other.minutes;
        }
        if (seconds != other.seconds) {
            return seconds - other.seconds;
        }
        if (milliseconds != other.milliseconds) {
            return milliseconds - other.milliseconds;
        }
        return 0;
    }

    @Override
    public String toString() {
        return String.format("%d:%02d:%03d",
                minutes, seconds, milliseconds);
    }
}

class F1Driver implements Comparable<F1Driver> {
    private String name;
    List<Lap> laps;

    public F1Driver(String line) {
        String[] parts = line.split("\\s+");
        this.name = parts[0];
        this.laps = new ArrayList<>(3);
        for (int i = 1; i <= 3; i++) {
            laps.add(new Lap(parts[i]));
        }
    }

    public Lap getFastestLap() {
        return Collections.min(laps);
    }

    @Override
    public int compareTo(F1Driver other) {
        return getFastestLap().compareTo(other.getFastestLap());
    }

    @Override
    public String toString() {
        return String.format("%-10s%10s",
                name, getFastestLap());
    }
}

class F1Race {
    List<F1Driver> drivers;

    public F1Race() {
        this.drivers = new ArrayList<>();
    }

    public void readResults(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        drivers = bufferedReader.lines()
                .map(F1Driver::new)
                .collect(Collectors.toList());
        bufferedReader.close();
    }

    public void printSorted(OutputStream out) {
        PrintWriter printWriter = new PrintWriter(out);
        Collections.sort(drivers);
        for (int i = 0; i < drivers.size(); i++) {
            printWriter.println(i + 1 + ". " + drivers.get(i));
        }
        printWriter.flush();
        printWriter.close();
    }
}

public class F1Test {

    public static void main(String[] args) {
        F1Race f1Race = new F1Race();
        try {
            f1Race.readResults(System.in);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        f1Race.printSorted(System.out);
    }

}

