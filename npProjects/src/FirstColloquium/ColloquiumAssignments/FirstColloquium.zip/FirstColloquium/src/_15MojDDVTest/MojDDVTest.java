package _15MojDDVTest;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

enum TaxType {
    A, B, V
}

class AmountNotAllowedException extends Exception {
    public AmountNotAllowedException(int amount) {
        super(String.format("Receipt with amount %d is not allowed to be scanned", amount));
    }
}

class Item {
    private int price;
    private TaxType tax;

    public Item(int price, TaxType tax) {
        this.price = price;
        this.tax = tax;
    }

    public Item(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public TaxType getTax() {
        return tax;
    }

    public void setTax(TaxType tax) {
        this.tax = tax;
    }

    public double getCalculatedTax() {
        if (tax.equals(TaxType.A))
            return 0.18 * price;
        else if (tax.equals(TaxType.B))
            return 0.05 * price;
        else
            return 0.0;
    }

    public double getDDV() {
        return getCalculatedTax() * 0.15;
    }
}

class Receipt implements Comparable<Receipt> {
    private long ID;
    private List<Item> items;

    public Receipt(long ID, List<Item> items) {
        this.ID = ID;
        this.items = items;
    }

    public Receipt(long ID) {
        this.ID = ID;
        this.items = new ArrayList<>();
    }

    public static Receipt create(String line) throws AmountNotAllowedException {
        String[] parts = line.split("\\s+");
        long ID = Long.parseLong(parts[0]);
        List<Item> items = new ArrayList<>();
        Arrays.stream(parts)
                .skip(1) // -> skip na long ID
                .forEach(i -> {
                    if (Character.isDigit(i.charAt(0))) {
                        items.add(new Item(Integer.parseInt(i)));
                    } else {
                        items.get(items.size() - 1).setTax(TaxType.valueOf(i));
                    }
                });
        if (totalAmount(items) > 30000)
            throw new AmountNotAllowedException(totalAmount(items));
        return new Receipt(ID, items);
    }

    public static int totalAmount(List<Item> items) {
        return items.stream().mapToInt(Item::getPrice).sum();
    }

    public int totalAmount() {
        return items.stream().mapToInt(Item::getPrice).sum();
    }

    public double taxReturns() {
//        return items.stream().mapToDouble(Item::getCalculatedTax).sum() * 0.15;
        return items.stream().mapToDouble(Item::getDDV).sum();
    }

    public long getID() {
        return ID;
    }

    @Override
    public int compareTo(Receipt other) {
        return Comparator.comparing(Receipt::taxReturns)
                .thenComparing(Receipt::totalAmount)
                .compare(this, other);
    }

    @Override
    public String toString() {
        return String.format("%d %d %.2f", ID, totalAmount(), taxReturns());
    }
}

class MojDDV {
    List<Receipt> receipts;

    public MojDDV() {
        this.receipts = new ArrayList<>();
    }

    public void readRecords(InputStream in) {
        receipts = new BufferedReader(new InputStreamReader(in))
                .lines()
                .map(line -> {
                    try {
                        return Receipt.create(line);
                    } catch (AmountNotAllowedException e) {
                        System.out.println(e.getMessage());
                        return null;
                    }
                })
                .collect(Collectors.toList());
        receipts = receipts.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }

    public void printTaxReturns(PrintStream out) {
        PrintWriter printWriter = new PrintWriter(out);
        receipts.stream()
                .forEach(i -> out.println(i.toString()));
        printWriter.flush();
    }
}

public class MojDDVTest {

    public static void main(String[] args) {

        MojDDV mojDDV = new MojDDV();

        System.out.println("===READING RECORDS FROM INPUT STREAM===");
        mojDDV.readRecords(System.in);

        System.out.println("===PRINTING TAX RETURNS RECORDS TO OUTPUT STREAM ===");
        mojDDV.printTaxReturns(System.out);

    }
}

