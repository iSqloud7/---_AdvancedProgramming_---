package _24RiskTester;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

class Round {
    private final List<Integer> attacker;
    private final List<Integer> defender;

    public Round(String line) {
        String[] parts = line.split(";");
        attacker = parseDice(parts[0]);
        defender = parseDice(parts[1]);
    }

    private List<Integer> parseDice(String line) {
        return Arrays.stream(line.split("\\s+"))
                .map(dice -> Integer.parseInt(dice))
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());
    }

    public boolean isWinner() {
        return IntStream.range(0, attacker.size())
                .allMatch(i -> attacker.get(i) > defender.get(i));
    }
}

class Risk {
    public int processAttacksData(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        List<Round> rounds = bufferedReader.lines()
                .map(Round::new)
                .collect(Collectors.toList());
        bufferedReader.close();

        return (int) rounds.stream()
                .filter(Round::isWinner)
                .count();
    }
}

public class RiskTester {
    public static void main(String[] args) {

        Risk risk = new Risk();

        try {
            System.out.println(risk.processAttacksData(System.in));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}

