package _3FileSystemTest;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Да се декларира интерфејсот IFile со соодветни методи,
 * така што секој фајл/датотека ќе ги има следните карактеристики:
 * -може да се пристапи до неговото име (String getFileName())
 * -може да се добие неговата големина во long (long getFileSize())
 * -може да се добие String репрезентација на фајлот (String getFileInfo(???))
 * -може да се сортира датотеката доколку е колекција од датотеки според големините на датотеките кои ги содржи (void sortBySize())
 * -може да се пресмета големината на најголемата обична датотека во датотеката (findLargestFile ())
 */

class IndentPrinter {
    /**
     * При генерирање на String репрезентација на
     * директориумите, датотеките и поддиректориумите во тој директориум
     * да се вовлечени со таб ("\t").
     */
    /*
    public static String printIndentation(int level) {
        return IntStream.range(0, level)
                .mapToObj(i -> "\t")
                .collect(Collectors.joining());
//        StringBuilder indentation = new StringBuilder();
//        for (int i = 0; i < level; i++) {
//            indentation.append("\t");
//        }
//        return indentation.toString();
    }
     */
    public static String printIndentation(int level) {
        return " ".repeat(level * 4);
    }
}

interface IFile extends Comparable<IFile> {
    String getFileName();

    long getFileSize();

    String getFileInfo(int indent);

    void sortBySize();

    long findLargestFile();
}

/**
 * Постојат два типа на фајлови:
 * File (обична датотека) и Folder (директориум/фолдер).
 * Потребно е овие две класи да го имплементираат интерфејсот IFile.
 * И во двете класи да се имплементираат методите коишто се декларирани во интерфејсот IFile.
 */

class File implements IFile {
    /**
     * За еден File се чуваат информации за неговото име и големина (во long).
     */

    protected String fileName;
    protected long filesSize;

    public File(String fileName, long filesSize) {
        this.fileName = fileName;
        this.filesSize = filesSize;
    }

    public File(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public String getFileName() {
        return this.fileName;
    }

    @Override
    public long getFileSize() {
        return this.filesSize;
    }

    @Override
    public String getFileInfo(int indent) {
        /**
         String репрезентацијата на една обична датотека е
         File name [името на фајлот со 10 места порамнето на десно] File size: [големината на фајлот со 10 места пораменета на десно ]
         */
        return String.format("%sFile name: %10s File size: %10d\n",
                IndentPrinter.printIndentation(indent), getFileName(), getFileSize());
    }

    @Override
    public void sortBySize() {
        /**
         Возможно е сортирање само во рамки на директориум,
         каде што сите датотеки во тој директориум потребно е да се сортираат
         според големина во растечки редослед.
         */
        return; // -> ова е за големина на Folder-от
    }

    @Override
    public long findLargestFile() {
        /**
         Методот getLargestFile() треба да ја врати големината
         на најголемата обична датотека во рамки на датотеката каде што е повикан.
         */
        return this.filesSize;
    }

    @Override
    public int compareTo(IFile other) {
        /** Имплементација според големина */
        return Long.compare(this.filesSize, other.getFileSize());
    }
}

class FileNameExistsException extends Exception {
    public FileNameExistsException(String fileName, String folderName) {
        super(String.format("There is already a file named %s in the folder %s",
                fileName, folderName));
    }
}

class Folder extends File implements IFile {
    /**
     * Во класата Folder се чуваат исти информации како и за File,
     * a дополнително се чува и листа од фајлови (и обични и директориуми).
     * За оваа класа да се имплементираат методите:
     * -void addFile (IFile file) - метод за додавање на било каква датотека во листата од датотеки.
     * Доколку веќе постои датотека со исто име како името на датотеката што се додава како аргумент на методот,
     * да се фрли исклучок од тип FileNameExistsException во којшто се проследува името кое веќе постои.
     */

    private List<IFile> files;

    public Folder(String fileName) {
        super(fileName);
        files = new ArrayList<>();
    }

    @Override
    public String getFileName() {
        return this.fileName;
    }

    @Override
    public long getFileSize() {
        /**
         Големината на еден Folder е сума од големините на сите датотеки
         (обични или директориуми) коишто се наоѓаат во него.
         */
        return files.stream()
                .mapToLong(IFile::getFileSize)
                .sum();
    }

    @Override
    public String getFileInfo(int indent) {
        /**
         String репрезентацијата на еден директориум е
         Folder name [името на директориумот со 10 места порамнето на десно] Folder size: [големината на директориумот со 10 места пораменета на десно ]
         */
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.format("%sFolder name: %10s Folder size: %10d\n",
                IndentPrinter.printIndentation(indent), getFileName(), getFileSize()));
        files.stream()
                .forEach(file -> stringBuilder.append(file.getFileInfo(indent + 1)));
        return stringBuilder.toString();
    }

    @Override
    public void sortBySize() {
        /**
         Возможно е сортирање само во рамки на директориум,
         каде што сите датотеки во тој директориум потребно е да се сортираат
         според големина во растечки редослед.

         Kога се повикува методот sortBySize() кај директориум
         истиот треба да се повика и за сите негови подиректориуми
         */
//        I-OPTION
        Comparator<IFile> comparator = Comparator.comparingLong(IFile::getFileSize);
        files.sort(comparator);
//        II-OPTION
        files.stream()
                .forEach(IFile::sortBySize);
    }

    @Override
    public long findLargestFile() {
        /**
         Методот getLargestFile() треба да ја врати големината
         на најголемата обична датотека во рамки на датотеката каде што е повикан.
         */
        OptionalLong largest = files.stream()
                .mapToLong(IFile::findLargestFile)
                .max();
        if (largest.isPresent())
            return largest.getAsLong();
        else return 0;
    }

    private boolean ifNameExists(String fileName) {
        return files.stream()
                .map(IFile::getFileName)
                .anyMatch(name -> name.equals(fileName));
    }

    public void addFile(IFile file) throws FileNameExistsException {
        if (ifNameExists(file.getFileName()))
            throw new FileNameExistsException(file.getFileName(), this.fileName);
        files.add(file);
    }

}

class FileSystem {
    /**
     * Да се дефинира класа FileSystem во која што ќе се чува
     * само еден директориум (rootDirectory).
     * За класата да се имплементираат:
     * -default конструктор FileSystem()
     * -void addFile (IFile file) - метод за додавање на било каква датотека во root директориумот.
     * -long findLargestFile () - метод којшто ја враќа големината на најголемата (обична) датотека во root директориумот.
     * -void sortBySize() - метод којшто ги сортира датотеките во root директориумот ( и обични и директориуми)
     * според нивната големина во root директориумот во растечки редослед.
     */
    private Folder root;

    public FileSystem() {
        this.root = new Folder("root");
    }

    public void addFile(IFile file) throws FileNameExistsException {
        root.addFile(file);
    }

    public long findLargestFile() {
        return root.findLargestFile();
    }

    public void sortBySize() {
        root.sortBySize();
    }

    @Override
    public String toString() {
        return this.root.getFileInfo(0);
    }
}

public class FileSystemTest {

    public static Folder readFolder(Scanner sc) {

        Folder folder = new Folder(sc.nextLine());
        int totalFiles = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < totalFiles; i++) {
            String line = sc.nextLine();

            if (line.startsWith("0")) {
                String fileInfo = sc.nextLine();
                String[] parts = fileInfo.split("\\s+");
                try {
                    folder.addFile(new File(parts[0], Long.parseLong(parts[1])));
                } catch (FileNameExistsException e) {
                    System.out.println(e.getMessage());
                }
            } else {
                try {
                    folder.addFile(readFolder(sc));
                } catch (FileNameExistsException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return folder;
    }

    public static void main(String[] args) {

        //file reading from input

        Scanner sc = new Scanner(System.in);

        System.out.println("===READING FILES FROM INPUT===");
        FileSystem fileSystem = new FileSystem();
        try {
            fileSystem.addFile(readFolder(sc));
        } catch (FileNameExistsException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("===PRINTING FILE SYSTEM INFO===");
        System.out.println(fileSystem.toString());

        System.out.println("===PRINTING FILE SYSTEM INFO AFTER SORTING===");
        fileSystem.sortBySize();
        System.out.println(fileSystem.toString());

        System.out.println("===PRINTING THE SIZE OF THE LARGEST FILE IN THE FILE SYSTEM===");
        System.out.println(fileSystem.findLargestFile());


    }
}
