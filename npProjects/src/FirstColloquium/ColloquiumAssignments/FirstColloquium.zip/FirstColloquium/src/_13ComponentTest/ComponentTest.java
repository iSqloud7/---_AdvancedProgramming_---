package _13ComponentTest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

class Component implements Comparable<Component> {
    private String color;
    private int weight;
    List<Component> components;
    private int position;

    public Component(String color, int weight) {
        this.color = color;
        this.weight = weight;
        this.components = new ArrayList<>();
        this.position = -1;
    }

    public int getPosition() {
        return position;
    }

    public Component setPosition(int position) {
        this.position = position;
        return this;
    }

    public String getColor() {
        return color;
    }

    public int getWeight() {
        return weight;
    }


    public void sorting() {
        components = components.stream()
                .sorted()
                .collect(Collectors.toList());
    }

    public void addComponent(Component component) {
        components.add(component);
        sorting();
    }

    @Override
    public int compareTo(Component other) {
        if (weight == other.weight) {
            if (color.compareTo(other.color) == 0) {
                return Integer.compare(other.components.stream()
                                .mapToInt(component -> component.weight)
                                .sum(),
                        components.stream()
                                .mapToInt(component -> component.weight)
                                .sum());
            }
            return color.compareTo(other.color);
        }
        return Integer.compare(weight, other.weight);
    }


    public String getComponentString(int intend) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < intend; i++) {
            stringBuilder.append("---");
        }
        stringBuilder.append(String.format("%d:%s\n",
                weight, color));
        components.forEach(component -> stringBuilder.append(component.getComponentString((intend + 1))));
        return stringBuilder.toString();
    }

    public void changeColor(int weight, String color) {
        if (this.weight < weight)
            this.color = color;
        if (!components.isEmpty()) {
            components.forEach(component -> component.changeColor(weight, color));
        }
        sorting();
    }
}

class InvalidPositionException extends Exception {
    public InvalidPositionException(String message) {
        super(message);
    }
}

class Window {
    private String name;
    private List<Component> components;

    public Window(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }

    public void sorting() {
        components = components.stream()
                .sorted(Comparator.comparingInt(Component::getPosition))
                .collect(Collectors.toList());
    }

    public void addComponent(int position, Component component) throws InvalidPositionException {
        if(components.isEmpty()){
            components.add(component.setPosition(position));
            return;
        }
        for (Component value : components) {
            if (value.getPosition() == position) {
                throw new InvalidPositionException(String.format("Invalid position %d, alredy taken!",
                        position));
            }
        }
        components.add(component.setPosition(position));
        sorting();
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WINDOW ").append(name).append("\n");
        components.forEach(component -> stringBuilder.append(component.getPosition()).append(":").append(component.getComponentString(0)));
        return stringBuilder.toString();
    }

    public void changeColor(int weight, String color) {
        for (Component component : components) {
            component.changeColor(weight, color);
        }
        sorting();
    }

    public void swichComponents(int p1, int p2) {
        int tmp1 = 0;
        int tmp2 = 0;
        Component component1 = null;
        Component component2 = null;
        for (Component component : components) {
            if (component.getPosition() == p1) {
                tmp1 = p1;
                component1 = component;
            } else if (component.getPosition() == p2) {
                tmp2 = p2;
                component2 = component;
            }
        }
        int tmp = tmp1;
        component1.setPosition(tmp2);
        component2.setPosition(tmp);
        sorting();
    }
}

public class ComponentTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        Window window = new Window(name);
        Component prev = null;
        while (true) {
            try {
                int what = scanner.nextInt();
                scanner.nextLine();
                if (what == 0) {
                    int position = scanner.nextInt();
                    window.addComponent(position, prev);
                } else if (what == 1) {
                    String color = scanner.nextLine();
                    int weight = scanner.nextInt();
                    Component component = new Component(color, weight);
                    prev = component;
                } else if (what == 2) {
                    String color = scanner.nextLine();
                    int weight = scanner.nextInt();
                    Component component = new Component(color, weight);
                    prev.addComponent(component);
                    prev = component;
                } else if (what == 3) {
                    String color = scanner.nextLine();
                    int weight = scanner.nextInt();
                    Component component = new Component(color, weight);
                    prev.addComponent(component);
                } else if (what == 4) {
                    break;
                }

            } catch (InvalidPositionException e) {
                System.out.println(e.getMessage());
            }
            scanner.nextLine();
        }

        System.out.println("=== ORIGINAL WINDOW ===");
        System.out.println(window);
        int weight = scanner.nextInt();
        scanner.nextLine();
        String color = scanner.nextLine();
        window.changeColor(weight, color);
        System.out.println(String.format("=== CHANGED COLOR (%d, %s) ===", weight, color));
        System.out.println(window);
        int pos1 = scanner.nextInt();
        int pos2 = scanner.nextInt();
        System.out.println(String.format("=== SWITCHED COMPONENTS %d <-> %d ===", pos1, pos2));
        window.swichComponents(pos1, pos2);
        System.out.println(window);
    }
}


