package _23QuizTest;

import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

abstract class Question implements Comparable<Question> {
    private String text;
    private int points;

    public String getText() {
        return text;
    }

    public int getPoints() {
        return points;
    }

    public Question(String text, int points) {
        this.text = text;
        this.points = points;
    }

    abstract String type();

    abstract double answer(String answer);

    @Override
    public int compareTo(Question other) {
        return Double.compare(this.points, other.points);
    }
}

class MultipleChoiceQuestion extends Question {
    String answer;

    public MultipleChoiceQuestion(String text, int points, String answer) {
        super(text, points);
        this.answer = answer;
    }

    @Override
    String type() {
        return "MC";
    }

    @Override
    double answer(String a) {
        if (a.equals(answer))
            return getPoints() * 1.0;
        return getPoints() * 0.20 * (-1);
    }

    @Override
    public String toString() {
        return String.format("Multiple Choice Question: %s Points %d Answer: %s",
                getText(), getPoints(), answer);
    }
}

class TrueFalseQuestion extends Question {
    boolean answer;

    public TrueFalseQuestion(String text, int points, boolean answer) {
        super(text, points);
        this.answer = answer;
    }

    @Override
    String type() {
        return "TF";
    }

    @Override
    double answer(String a) {
        if (Boolean.parseBoolean(a) == answer) {
            return getPoints();
        }
        return 0.0;
    }

    @Override
    public String toString() {
        String a = "";
        if (answer) a = "true";
        else a = "false";
        return String.format("True/False Question: %s Points: %d Answer: %s",
                getText(), getPoints(), answer);
    }
}

class InvalidOperationException extends Exception {
    public InvalidOperationException(String message) {
        super(message);
    }
}

class Quiz {
    List<Question> questions;

    public Quiz() {
        this.questions = new ArrayList<>();
    }

    public void addQuestion(String questData) throws InvalidOperationException {
        String[] parts = questData.split(";");
        if (parts[0].equals("MC")) {
            char answer = 'A';
            int i;
            for (i = 0; i < 5; i++) {
                if (parts[3].charAt(0) == answer) {
                    break;
                }
                answer++;
            }
            if (i == 5)
                throw new InvalidOperationException(String.format("%s is not allowed option for this question",
                        parts[3]));
            questions.add(new MultipleChoiceQuestion(parts[1], Integer.parseInt(parts[2]), parts[3]));
        } else {
            boolean type;
            type = parts[3].equals("true");
            questions.add(new TrueFalseQuestion(parts[1], Integer.parseInt(parts[2]), type));
        }
    }

    public void printQuiz(OutputStream out) {
        PrintWriter printWriter = new PrintWriter(out);
        questions.stream()
                .sorted(Comparator.reverseOrder())
                .forEach(printWriter::println);
        printWriter.flush();
        printWriter.close();
    }

    public void answerQuiz(List<String> answers, PrintStream out) throws InvalidOperationException {
        PrintWriter printWriter = new PrintWriter(out);
        double totalPoints = 0.0;
        if (answers.size() != questions.size())
            throw new InvalidOperationException("Answers and questions must be of same length!");
        for (int i = 0; i < answers.size(); i++) {
            double point = questions.get(i).answer(answers.get(i));
            totalPoints += point;
            printWriter.println(String.format("%d. %.2f",
                    i + 1, point));
        }
        printWriter.println(String.format("Total points: %.2f",
                totalPoints));
        printWriter.flush();
        printWriter.close();
    }
}

public class QuizTest {
    public static void main(String[] args) throws InvalidOperationException {

        Scanner sc = new Scanner(System.in);

        Quiz quiz = new Quiz();

        int questions = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < questions; i++) {
            try {
                quiz.addQuestion(sc.nextLine());
            } catch (InvalidOperationException e) {
                System.out.println(e.getMessage());
            }
        }

        List<String> answers = new ArrayList<>();

        int answersCount = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < answersCount; i++) {
            answers.add(sc.nextLine());
        }

        int testCase = Integer.parseInt(sc.nextLine());

        if (testCase == 1) {
            quiz.printQuiz(System.out);
        } else if (testCase == 2) {
            try {
                quiz.answerQuiz(answers, System.out);
            } catch (InvalidOperationException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("Invalid test case");
        }
    }
}

