package _16MojDDVTest;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

enum TaxType {
    A, B, V
}

class AmountNotAllowedException extends Exception {
    public AmountNotAllowedException(int amount) {
        super(String.format("Receipt with amount %d is not allowed to be scanned", amount));
    }
}

class Item {
    private int price;
    private TaxType tax;

    public Item(int price, TaxType tax) {
        this.price = price;
        this.tax = tax;
    }

    public Item(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public TaxType getTax() {
        return tax;
    }

    public void setTax(TaxType tax) {
        this.tax = tax;
    }

    public double getCalculatedTax() {
        if (tax.equals(TaxType.A))
            return 0.18 * price;
        else if (tax.equals(TaxType.B))
            return 0.05 * price;
        else
            return 0.0;
    }

    public double getDDV() {
        return getCalculatedTax() * 0.15;
    }
}

class Receipt implements Comparable<Receipt> {
    //    ID item_price1 item_tax_type1 item_price2 item_tax_type2 === -> List<Item> (int_price + enum_tax)
    private long ID;
    private List<Item> items;

    public Receipt(long ID, List<Item> items) {
        this.ID = ID;
        this.items = items;
    }

    public Receipt(long ID) {
        this.ID = ID;
        this.items = new ArrayList<>();
    }

    public static Receipt create(String line) throws AmountNotAllowedException {
//        12334 (1789 А 1238 B 1222 V 111 V)
        String[] parts = line.split("\\s+");
        long ID = Long.parseLong(parts[0]);
        List<Item> items = new ArrayList<>();
        Arrays.stream(parts)
                .skip(1) // -> skip na long ID
                .forEach(i -> {
                    if (Character.isDigit(i.charAt(0))) {
                        items.add(new Item(Integer.parseInt(i)));
                    } else {
                        items.get(items.size() - 1).setTax(TaxType.valueOf(i));
                    }
                });
        if (totalAmount(items) > 30000)
            throw new AmountNotAllowedException(totalAmount(items));
        return new Receipt(ID, items);
    }

    public static int totalAmount(List<Item> items) {
        return items.stream().mapToInt(Item::getPrice).sum();
    }

    public int totalAmount() {
        return items.stream().mapToInt(Item::getPrice).sum();
    }

    public double taxReturns() {
//        return items.stream().mapToDouble(Item::getCalculatedTax).sum() * 0.15;
        return items.stream().mapToDouble(Item::getDDV).sum();
    }

    public long getID() {
        return ID;
    }

    @Override
    public int compareTo(Receipt other) {
        return Comparator.comparing(Receipt::taxReturns)
                .thenComparing(Receipt::totalAmount)
                .compare(this, other);
    }

    @Override
    public String toString() {
//        ID SUM_OF_AMOUNTS TAX_RETURN
//        return "\t" + ID + "\t" + totalAmount() + "\t" + taxReturns();
        return String.format("%10d\t%10d\t%10.5f", ID, totalAmount(), taxReturns());
    }
}

class MojDDV {
    List<Receipt> receipts;

    public MojDDV() {
        this.receipts = new ArrayList<>();
    }

    /**
     * void readRecords (InputStream inputStream)
     * - метод којшто ги чита од влезен тек податоците за фискалните сметки.
     * Доколку е скенирана фискална сметка со износ поголем од 30000 денари,
     * потребно е да се фрли исклучок од тип AmountNotAllowedException.
     * Дефинирајте каде ќе се фрла исклучокот, и каде ќе биде фатен, на начин што оваа функција,
     * ќе може да ги прочита сите фискални коишто се скенирани.
     * Исклучокот треба да испечати порака
     * “Receipt with amount [сума на сите артикли] is not allowed to be scanned”.
     */
    public void readRecords(InputStream in) {
        receipts = new BufferedReader(new InputStreamReader(in))
                .lines()
                .map(line -> {
                    try {
                        return Receipt.create(line);
                    } catch (AmountNotAllowedException e) {
                        System.out.println(e.getMessage());
                        return null;
                    }
                })
                .collect(Collectors.toList());
        receipts = receipts.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }

    /**
     * void printTaxReturns (OutputStream outputStream)
     * - метод којшто на излезен тек ги печати сите скенирани фискални сметки во формат:
     * ID SUM_OF_AMOUNTS TAX_RETURN,
     * каде што SUM_OF_AMOUNTS e збирот на сите артикли во фискалната сметка,
     * а TAX_RETURN е пресметаниот повраток на ДДВ за таа фискална сметка.
     */
    public void printTaxReturns(PrintStream out) {
        PrintWriter printWriter = new PrintWriter(out);
        receipts.stream()
//                .sorted()
                .forEach(i -> out.println(i.toString()));
        printWriter.flush();
    }

    /*
    void printStatistics (OutputStream outputStream)
    - метод којшто на излезен тек печати статистики за повратокот на ДДВ од сите скенирани фискални сметки во формат min:
    MIN max: MAX sum: SUM count: COUNT average: AVERAGE,
    при што секоја од статистиките е во нов ред,
    а пак вредноста на статистиката е оддалечена со таб од името на статистиката (погледнете тест пример).
    Децималните вредности се печатат со 5 места, од кои 3 се за цифрите после децималата.
    Целите вредности се пишуваат со 5 места (порамнети на лево).
    */
    public void printStatistics(PrintStream out) {
        PrintWriter printWriter = new PrintWriter(out);
        DoubleSummaryStatistics doubleSummaryStatistics = receipts.stream()
                .mapToDouble(Receipt::taxReturns)
                .summaryStatistics();
        printWriter.println(String.format("min:\t%.3f\nmax:\t%.3f\nsum:\t%.3f\ncount:\t%d\navg:\t%.3f\n",
                doubleSummaryStatistics.getMin(),
                doubleSummaryStatistics.getMax(),
                doubleSummaryStatistics.getSum(),
                doubleSummaryStatistics.getCount(),
                doubleSummaryStatistics.getAverage()));
        printWriter.flush();
    }
}

public class MojDDVTest {

    public static void main(String[] args) {

        MojDDV mojDDV = new MojDDV();

        System.out.println("===READING RECORDS FROM INPUT STREAM===");
        mojDDV.readRecords(System.in);

        System.out.println("===PRINTING TAX RETURNS RECORDS TO OUTPUT STREAM ===");
        mojDDV.printTaxReturns(System.out);

        System.out.println("===PRINTING SUMMARY STATISTICS FOR TAX RETURNS TO OUTPUT STREAM===");
        mojDDV.printStatistics(System.out);

    }
}
